package com.example.resourcemanager;

import java.util.Comparator;

public class Model
{
    String Name, Level, Drop, Craftable, purl, burl, desc;

    Model()
    {}

    public Model(String name, String level, String drop, String craftable, String purl, String burl, String desc) {
        Name = name;
        Level = level;
        Drop = drop;
        Craftable = craftable;
        this.purl = purl;
        this.burl = burl;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getBurl() {
        return burl;
    }

    public void setBurl(String burl) {
        this.burl = burl;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        this.Level = level;
    }

    public String getDrop() {
        return Drop;
    }

    public void setDrop(String drop) {
        this.Drop = drop;
    }

    public String getCraftable() {
        return Craftable;
    }

    public void setCraftable(String craftable) {
        this.Craftable = craftable;
    }

    public String getPurl() {
        return purl;
    }

    public void setPurl(String purl) {
        this.purl = purl;
    }

    //sort
    public static final Comparator<Model> By_NAME_ASCENDING = new Comparator<Model>() {
        @Override
        public int compare(Model o1, Model o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };

    public static final Comparator<Model> By_NAME_DESCENDING = new Comparator<Model>() {
        @Override
        public int compare(Model o1, Model o2) {
            return o2.getName().compareTo(o1.getName());
        }
    };

    public static final Comparator<Model> By_LEVEL_ASCENDING = new Comparator<Model>() {
        @Override
        public int compare(Model o1, Model o2) {
            return o1.getLevel().compareTo(o2.getLevel());
        }
    };

    public static final Comparator<Model> By_LEVEL_DESCENDING = new Comparator<Model>() {
        @Override
        public int compare(Model o1, Model o2) {
            return o2.getLevel().compareTo(o1.getLevel());
        }
    };
}
