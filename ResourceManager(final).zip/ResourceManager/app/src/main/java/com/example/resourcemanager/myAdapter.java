package com.example.resourcemanager;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.telecom.Call;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class myAdapter extends RecyclerView.Adapter<myViewholder> implements Filterable
{
    Context c;
    ArrayList<Model> models, filterList;
    CustomFilter filter;

    public myAdapter(Context c, ArrayList<Model> models) {
        this.c = c;
        this.models = models;
        this.filterList = models;

    }


    @NonNull
    @Override
    public myViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        return new myViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewholder holder, int position) {
        holder.Name.setText(models.get(position).getName());
        holder.Level.setText(models.get(position).getLevel());
        Glide.with(holder.img.getContext()).load(models.get(position).getPurl()).into(holder.img);

        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickListener(View v, int position) {

                String gName = models.get(position).getName();
                String gLevel = models.get(position).getLevel();
                String gDrop = models.get(position).getDrop();
                String gCraftable = models.get(position).getCraftable();
                String gPurl = models.get(position).getPurl();
                String gBurl = models.get(position).getBurl();
                String gDesc = models.get(position).getDesc();

                Intent intent = new Intent(c, Detail.class);
                intent.putExtra("iName", gName);
                intent.putExtra("iLevel", gLevel);
                intent.putExtra("iDrop", gDrop);
                intent.putExtra("iCraftable", gCraftable);
                intent.putExtra("iPurl", gPurl);
                intent.putExtra("iBurl", gBurl);
                intent.putExtra("iDesc", gDesc);
                c.startActivity(intent);

            }
        });

    }


    @Override
    public int getItemCount() {
        return models.size();
    }


    @Override
    public Filter getFilter() {
        if (filter == null){
            filter = new CustomFilter(filterList, this);

        }

        return filter;
    }
}

