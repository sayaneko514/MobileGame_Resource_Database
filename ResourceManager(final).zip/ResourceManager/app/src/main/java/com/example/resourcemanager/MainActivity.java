package com.example.resourcemanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.SearchView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity
{
    RecyclerView recyclerView;
    myAdapter adapter;

    SharedPreferences preferences;

    ArrayList<Model> list = new ArrayList<Model>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);

        preferences = this.getSharedPreferences("My_Pref", MODE_PRIVATE);

        DatabaseReference mDatabase;
        mDatabase = FirebaseDatabase.getInstance().getReference();

        DatabaseReference mOptionReference = mDatabase.child("Mats");

        ValueEventListener optionListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                ArrayList<String> names = new ArrayList<>();
                for(DataSnapshot name : dataSnapshot.getChildren()) {
                    names.add(name.getKey());
                    Model option = name.getValue(Model.class);
                    list.add(option);

                }

                adapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("LoadModel:onCancelled", databaseError.toException());
            }
        };
        mOptionReference.addValueEventListener(optionListener);

        getList();




    }




    @Override
    public void onStart()
    {
        super.onStart();



    }

    @Override
    public void onStop()
    {
        super.onStop();

    }

    private void getList(){


        String mSortSetting = preferences.getString("Sort", "ascending");

        if (mSortSetting.equals("ascending")){
            Collections.sort(list, Model.By_NAME_ASCENDING);
        }
        else if (mSortSetting.equals("descending")){
            Collections.sort(list, Model.By_NAME_DESCENDING);
        }

        else if (mSortSetting.equals("tascending")){
            Collections.sort(list, Model.By_LEVEL_ASCENDING);
        }

        else if (mSortSetting.equals("tdescending")){
            Collections.sort(list, Model.By_LEVEL_DESCENDING);
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new myAdapter(this, list);

        recyclerView.setAdapter(adapter);
    }

    //menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);

        MenuItem item = menu.findItem(R.id.search);

        SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                adapter.getFilter().filter(query);

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);

                return false;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.sorting){
            sortDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private  void sortDialog(){

        String[] options = {"Name Ascending", "Name Descending", "Tier Ascending", "Tier Descending"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Sort by");
        builder.setIcon(R.drawable.ic_action_sort);

        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0){
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("Sort", "ascending");
                    editor.apply();
                    getList();
                }

                if (which == 1){
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("Sort", "descending");
                    editor.apply();
                    getList();
                }
                if (which == 2){
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("Sort", "tascending");
                    editor.apply();
                    getList();
                }

                if (which == 3) {
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("Sort", "tdescending");
                    editor.apply();
                    getList();
                }
            }
        });

        builder.create().show();
    }

    public ArrayList<HashMap<String, Object>> recArrayList(DataSnapshot snapshot){

        ArrayList<HashMap<String, Object>> list = new ArrayList<>();

        if (snapshot == null){

            return list;
        }

        // This is awesome! You don't have to know the data structure of the database.
        Object fieldsObj = new Object();

        HashMap fldObj;

        for (DataSnapshot shot : snapshot.getChildren()){

            try{

                fldObj = (HashMap)shot.getValue(fieldsObj.getClass());

            }catch (Exception ex){

                // My custom error handler. See 'ErrorHandler' in Gist
//                ErrorHandler.logError(ex);

                continue;
            }

            // Include the primary key of this Firebase data record. Named it 'recKeyID'
            fldObj.put("recKeyID", shot.getKey());

            list.add(fldObj);
        }

        return list;
    }

}