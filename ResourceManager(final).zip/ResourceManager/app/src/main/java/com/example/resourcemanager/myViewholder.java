package com.example.resourcemanager;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class myViewholder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView img;
        TextView Name, Level;
        ItemClickListener itemClickListener;
        public myViewholder (@NonNull View itemView)
        {
            super(itemView);
            img = (ImageView)itemView.findViewById(R.id.imageIV);
            Name = (TextView)itemView.findViewById(R.id.titleTv);
            Level = (TextView)itemView.findViewById(R.id.descriptionTv);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {

            this.itemClickListener.onItemClickListener(view, getLayoutPosition());

        }

        public void setItemClickListener(ItemClickListener ic){

            this.itemClickListener = ic;

        }
}

