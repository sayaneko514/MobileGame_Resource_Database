package com.example.resourcemanager;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class Detail extends AppCompatActivity {

    TextView mNameTv, mLevelTv, mDropTv, mCraftTv, mDescTV;
    ImageView mImageIV, mbackIV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ActionBar actionBar = getSupportActionBar();

        mNameTv = findViewById(R.id.nameView);
        mLevelTv = findViewById(R.id.levelView);
        mDropTv = findViewById(R.id.locationView);
        mCraftTv = findViewById(R.id.craftView);
        mDescTV = findViewById(R.id.descView);
        mImageIV = findViewById(R.id.imageView);
        mbackIV = findViewById(R.id.imagebg);

        Intent intent = getIntent();

        String mName = intent.getStringExtra("iName");
        String mLevel = intent.getStringExtra("iLevel");
        String mDrop = intent.getStringExtra("iDrop");
        String mCraftable = intent.getStringExtra("iCraftable");
        String mDesc = intent.getStringExtra("iDesc");
        String mImage = intent.getStringExtra("iPurl");
        String mBg = intent.getStringExtra("iBurl");

        actionBar.setTitle(mName);
        mNameTv.setText(mName);
        mLevelTv.setText(mLevel);
        mDropTv.setText(mDrop);
        mCraftTv.setText(mCraftable);
        mDescTV.setText(mDesc);
        Glide.with(this).load(mImage).into(mImageIV);
        Glide.with(this).load(mBg).into(mbackIV);
    }
}